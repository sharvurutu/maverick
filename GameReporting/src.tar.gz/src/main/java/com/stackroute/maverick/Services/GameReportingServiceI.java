package com.stackroute.maverick.Services;

import com.stackroute.maverick.domain.AdaptiveResult;
import com.stackroute.maverick.domain.GameReports;
import com.stackroute.maverick.domain.MultiPlayerResult;
import com.stackroute.maverick.domain.SinglePlayerResult;
import com.stackroute.maverick.domain.UserActivity;

public interface GameReportingServiceI 
{	
	public GameReports addgamereports(GameReports gamereports);
	public Iterable<GameReports> getAllGameReports();
	public GameReports showGameById(int gameId);
	public GameReports showGameByName(String gameName);
	public Iterable<UserActivity> getAllGameReports1();
	public MultiPlayerResult addmultigamereports(MultiPlayerResult multiplayerresult);
	public Iterable<MultiPlayerResult> getAllMultiGameReports();
	public AdaptiveResult addadaptivereports(AdaptiveResult adaptiveresult);
	public Iterable<AdaptiveResult> getAllAdaptiveGameReports();
	public AdaptiveResult showAdaptbyUserId(int userId);
	public MultiPlayerResult showMultiByUserId(int userId);
} 
