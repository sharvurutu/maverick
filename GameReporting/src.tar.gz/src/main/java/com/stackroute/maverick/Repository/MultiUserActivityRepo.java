package com.stackroute.maverick.Repository;

import org.springframework.data.repository.CrudRepository;
import org.springframework.stereotype.Repository;

import com.stackroute.maverick.domain.MultiPlayerResult;

@Repository
public interface MultiUserActivityRepo extends CrudRepository<MultiPlayerResult,Integer>{

}
