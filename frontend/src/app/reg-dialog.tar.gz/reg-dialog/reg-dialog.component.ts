import { Component, OnInit, Inject } from '@angular/core';
import { MatDialog, MatDialogRef, MAT_DIALOG_DATA } from '@angular/material';
import { User } from '../model/user.model';
import { UserService } from '../services/user.service';
import { Router } from "@angular/router";
import { AuthenticationModel } from "../authentication.model"
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { FormsModule, FormControl, ReactiveFormsModule } from '@angular/forms';
import { MatRadioChange } from '@angular/material';
import { VERSION } from '@angular/material';

const EMAIL_REGEX = /^[a-zA-Z0-9.!#$%&’*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;

@Component({
  selector: 'app-reg-dialog',
  templateUrl: './reg-dialog.component.html',
  styleUrls: ['./reg-dialog.component.css']
})
export class RegDialogComponent {
  isLinear = false;
  firstFormGroup: FormGroup;
  secondFormGroup: FormGroup;
  constructor(
    private _formBuilder: FormBuilder,
    private router: Router,
    private userService: UserService,
    private _fb: FormBuilder) {
      this.testForm =this._fb.group({
        email: ['', [Validators.required, Validators.pattern(EMAIL_REGEX)]],
      });
     }
  user: User = new User();
  authenticationModel: AuthenticationModel = new AuthenticationModel();
  ngOnInit() {
    this.firstFormGroup = this._formBuilder.group({
      firstCtrl: ['', Validators.required]
    });
    this.secondFormGroup = this._formBuilder.group({
      secondCtrl: ['', Validators.required]
    });
  }
  regiseterUser(user: User) {
    this.userService.registerUser(user)
      .subscribe(data => {
        console.log("USER GENDER PASSED FROM HTML", user.location)
        alert("user created successfully");
        if (this.user.email != null && this.user.password != null) {
          this.router.navigate(['categorySuggetions']);
        }
      });
  }
  startDate = new Date(1990, 0, 1);

  array = ['Male', 'Female'];

  radioChange(event: MatRadioChange) {
    console.log(event.value);
  }

  version = VERSION;
  public testForm = new FormGroup({});

  public email: string;
  public errorTest:Array<any> = [
    {type:'pattern', msg:'Please enter a valid email address'},
    {type:'required', msg:'Email is <strong>required</strong>'},
  ];
}